// let express = require('express');
// const loginRouter = require('./authRouters/login-router');
// let router = express.Router();
// let userRouter  = require('./user-router');
// let registerRouter = require('./authRouters/register-router');
// let dataRouter = require('./data-router')
// router.use('/',dataRouter);



// module.exports = router