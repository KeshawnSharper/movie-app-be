<img src="https://res.cloudinary.com/di449masi/image/upload/v1606248006/Screen_Shot_2020-11-24_at_2.59.13_PM_ntpsc2.png"></img>

# Sneaker Store

# Description : 
A Sneaker store application similar to stockX.

# Functionality : 
The app allows users to search and filter through available homes from the Realtor API. Click on one of the properties to view more of it's data and photos.

# Status:
Complete and deployed 

# Tech framework :
ReactJS/JavaScript/Html/CSS/Redux/NodeJS/AWS

# Bugs:
No bugs 

# How to use it:

Link: https://heirfeet.netlify.app/
1. Sign up or Sign in with a Heir Feet account
2. On the home page choose a sneaker brand to search for or browse all to start
3. Filter between shoes with the side nav or top search bar then pick a shoe to "buy"
4. Pick to add a shoe to your cart and/or select a shoe
5. Click the cart icon this sends you to the cart page 
6. On the cart page delete cart items and/or purchase all items. 
7. Click the icon next to the cart to view all of your orders

